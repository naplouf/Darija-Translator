# 🇲🇦 Darija Translator — LLM-powered RESTful Web Service

> **Mini Project 2** · Pr. El Habib Nfaoui  
> Translates text from English (or other languages) to **Moroccan Arabic Dialect (Darija)** using Google Gemini AI, exposed as a secured Jakarta RESTful Web Service.

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                  Application Server (GlassFish/Payara)       │
│  ┌──────────────────────────────────────────────────────┐   │
│  │           darija-translator.war                       │   │
│  │  TranslatorApplication (@ApplicationPath /api)        │   │
│  │  TranslatorResource    (@Path /translator)            │   │
│  │  GeminiTranslationService ──────────────────────────────────► Google Gemini API
│  │  Jakarta Basic Authentication (web.xml)               │   │
│  │  CorsFilter (@Provider)                               │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
         ▲               ▲               ▲               ▲
   Chrome Ext       PHP Client     Python Client    React Native
  (Manifest V3)   (cURL + web)  (urllib/Tkinter)  (iOS/Android)
```

---

## 📁 Project Structure

```
darija-translator/
├── rest-service/                    # Maven WAR project
│   ├── pom.xml
│   └── src/
│       ├── main/java/ma/translator/
│       │   ├── TranslatorApplication.java   # JAX-RS bootstrap
│       │   ├── resource/
│       │   │   ├── TranslatorResource.java  # REST endpoint
│       │   │   └── CorsFilter.java
│       │   ├── service/
│       │   │   ├── TranslationService.java  # interface
│       │   │   ├── GeminiTranslationService.java
│       │   │   └── TranslationException.java
│       │   └── model/
│       │       ├── TranslationRequest.java
│       │       └── TranslationResponse.java
│       ├── main/resources/META-INF/
│       └── main/webapp/WEB-INF/
│           ├── web.xml              # Basic Auth config
│           └── glassfish-web.xml
│       └── test/java/ma/translator/
│           └── TranslatorResourceTest.java
│
├── chrome-extension/                # Manifest V3 Chrome extension
│   ├── manifest.json
│   ├── background.js               # Service worker
│   ├── content.js                  # Text selection listener
│   ├── sidepanel.html              # Side panel UI
│   ├── sidepanel.js
│   └── icons/
│
├── php-client/
│   └── index.php                   # Web UI + CLI PHP client
│
├── python-client/
│   ├── client.py                   # Tkinter GUI + CLI
│   └── requirements.txt
│
├── react-native-client/            # Expo / React Native app
│   ├── App.js
│   ├── package.json
│   └── src/
│       ├── screens/
│       │   ├── TranslatorScreen.js
│       │   └── SettingsScreen.js
│       └── services/
│           └── TranslatorApi.js
│
└── uml-diagrams/
    └── diagrams.html               # Class, Deployment, Use Case diagrams
```

---

## 🚀 Setup & Deployment

### Prerequisites
- Java 17+, Maven 3.9+
- GlassFish 7 or Payara 6 (Jakarta EE 10)
- A free [Google Gemini API key](https://ai.google.dev/pricing#1_5flash)

### 1 · Configure the API key

**Option A — environment variable (recommended):**
```bash
export GEMINI_API_KEY=your_key_here
```

**Option B — JVM system property:**
```bash
# In GlassFish domain.xml or asadmin
asadmin create-jvm-options "-Dgemini.api.key=your_key_here"
```

### 2 · Build the WAR
```bash
cd rest-service
mvn clean package
# Output: target/darija-translator.war
```

### 3 · Deploy to GlassFish/Payara
```bash
asadmin deploy target/darija-translator.war
```

Or drag-and-drop the WAR file into the GlassFish Admin Console at `http://localhost:4848`.

### 4 · Create users on the server

```bash
# Create the security realm
asadmin create-auth-realm \
  --classname com.sun.enterprise.security.auth.realm.file.FileRealm \
  --property file=${com.sun.aas.instanceRoot}/config/keyfile:jaas-context=fileRealm \
  DarijaTranslatorRealm

# Add a user
asadmin create-file-user \
  --groups translator-users \
  --authrealmname DarijaTranslatorRealm \
  translator-user
```

---

## 🔌 REST API Reference

**Base URL:** `http://localhost:8080/darija-translator/api/translator`

### Health Check (public)
```
GET /health
```
Response: `{"status":"UP","service":"Darija Translator"}`

---

### Translate via GET
```
GET /translate?text=Hello&lang=English
Authorization: Basic <base64(user:pass)>
```

### Translate via POST
```
POST /translate
Authorization: Basic <base64(user:pass)>
Content-Type: application/json

{
  "text": "Hello, how are you?",
  "sourceLanguage": "English"
}
```

**Success Response:**
```json
{
  "originalText": "Hello, how are you?",
  "translatedText": "آش حالك؟",
  "sourceLanguage": "English",
  "targetLanguage": "Darija (Moroccan Arabic)",
  "success": true
}
```

**Error Response:**
```json
{
  "success": false,
  "errorMessage": "Input text cannot be empty."
}
```

---

## 🧪 Testing with cURL

```bash
# Health check
curl http://localhost:8080/darija-translator/api/translator/health

# GET translation
curl -u translator-user:password123 \
  "http://localhost:8080/darija-translator/api/translator/translate?text=Good+morning&lang=English"

# POST translation
curl -u translator-user:password123 \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"text":"I love Morocco!","sourceLanguage":"English"}' \
  http://localhost:8080/darija-translator/api/translator/translate
```

---

## 🔒 Security

Authentication uses **Jakarta Basic Authentication** (`web.xml`). All `/translate` endpoints require valid credentials. The `/health` endpoint is public.

> ⚠️ For production: use HTTPS (uncomment `<transport-guarantee>CONFIDENTIAL</transport-guarantee>` in `web.xml`) and consider token-based auth.

---

## 🧩 Chrome Extension

1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode**
3. Click **Load unpacked** → select the `chrome-extension/` folder
4. Open extension settings → enter your server URL, username, password
5. **Right-click** any selected text → **"Translate to Darija 🇲🇦"**
6. Translation appears instantly in the **side panel**

**Features:**
- Auto-fills selected text
- Context menu integration
- Text-to-speech (Read Aloud) via Chrome TTS API
- Credentials stored in `chrome.storage.local`

---

## 🐍 Python Client

```bash
cd python-client

# GUI mode
python client.py

# CLI mode
python client.py --cli "Good morning!" --lang English

# Custom server
python client.py --cli "Hello" --server http://192.168.1.100:8080/darija-translator/api/translator
```

---

## 🐘 PHP Client

```bash
cd php-client
php -S localhost:3000
# Then open http://localhost:3000

# CLI mode
php index.php
```

---

## 📱 React Native (Expo)

```bash
cd react-native-client
npm install
npx expo start

# For Android emulator
npx expo start --android

# For iOS simulator
npx expo start --ios
```

> **Note:** The default server URL `http://10.0.2.2:8080/...` points to your machine from an Android emulator. Change it in the app's Settings screen for physical devices.

---

## 🧪 Running Tests

```bash
cd rest-service
mvn test
```

---

## 📊 UML Diagrams

Open `uml-diagrams/diagrams.html` in a browser to view:
- **Class Diagram** — full software structure
- **Deployment Diagram** — server/client physical layout
- **Use Case Diagram** — user interactions

---

## ✨ Extension Features

| Feature | Implementation |
|---|---|
| Speech translation (TTS) | Chrome TTS API / `expo-speech` |
| Read aloud | Side panel 🔊 button |
| Multi-language source | English, French, Spanish, Arabic, German |
| Secured endpoint | Jakarta Basic Auth |
| CORS support | `CorsFilter.java` |
| Local LLM swap | Implement `TranslationService` interface |

---

## 📄 License

MIT License — Mini Project 2 submission.

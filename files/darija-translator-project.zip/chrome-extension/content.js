// content.js — injected into every webpage

// Listen for text selection and send to background
document.addEventListener("mouseup", () => {
  const selected = window.getSelection().toString().trim();
  if (selected.length > 0) {
    chrome.runtime.sendMessage({
      action: "SELECTED_TEXT",
      text: selected
    });
  }
});

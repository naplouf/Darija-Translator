// background.js — Service Worker (Manifest V3)

// ─── Context Menu Setup ──────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "translate-darija",
    title: "Translate to Darija 🇲🇦",
    contexts: ["selection"]
  });
  console.log("Darija Translator installed.");
});

// ─── Context Menu Click ──────────────────────────────────────────────────────
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "translate-darija" && info.selectionText) {
    // Open (or focus) the side panel
    await chrome.sidePanel.open({ tabId: tab.id });

    // Small delay to let the side panel initialize
    setTimeout(() => {
      chrome.runtime.sendMessage({
        action: "TRANSLATE_SELECTION",
        text: info.selectionText.trim()
      });
    }, 400);
  }
});

// ─── Toolbar Icon Click — toggle side panel ──────────────────────────────────
chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ tabId: tab.id });
});

// ─── Message Relay ───────────────────────────────────────────────────────────
// Relay messages from content script → side panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "SELECTED_TEXT") {
    chrome.runtime.sendMessage({
      action: "TRANSLATE_SELECTION",
      text: message.text
    });
  }
});

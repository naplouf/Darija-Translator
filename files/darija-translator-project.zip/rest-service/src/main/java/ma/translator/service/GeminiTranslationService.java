package ma.translator.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Service that calls the Google Gemini API to perform translation
 * from any source language to Moroccan Arabic Dialect (Darija).
 */
public class GeminiTranslationService implements TranslationService {

    private static final Logger logger = LoggerFactory.getLogger(GeminiTranslationService.class);

    // API key loaded from environment variable or system property
    private static final String API_KEY = System.getenv().getOrDefault(
            "GEMINI_API_KEY",
            System.getProperty("gemini.api.key", "YOUR_GEMINI_API_KEY_HERE")
    );

    private static final String GEMINI_API_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + API_KEY;

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Translates text from the given source language to Moroccan Arabic Dialect (Darija).
     *
     * @param text           the text to translate
     * @param sourceLanguage the source language (e.g., "English", "French")
     * @return the translated text in Darija
     * @throws TranslationException if the translation fails
     */
    @Override
    public String translate(String text, String sourceLanguage) throws TranslationException {
        if (text == null || text.isBlank()) {
            throw new TranslationException("Input text cannot be empty.");
        }

        String prompt = buildPrompt(text, sourceLanguage);
        String requestBody = buildRequestBody(prompt);

        logger.info("Sending translation request for text: [{}]", text.substring(0, Math.min(50, text.length())));

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(GEMINI_API_URL);
            httpPost.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));
            httpPost.setHeader("Content-Type", "application/json");

            try (var response = httpClient.execute(httpPost)) {
                int statusCode = response.getCode();
                InputStream content = response.getEntity().getContent();
                String responseBody = new String(content.readAllBytes(), StandardCharsets.UTF_8);

                if (statusCode != 200) {
                    logger.error("Gemini API error {}: {}", statusCode, responseBody);
                    throw new TranslationException("Gemini API returned status: " + statusCode);
                }

                return parseGeminiResponse(responseBody);
            }
        } catch (TranslationException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Failed to call Gemini API", e);
            throw new TranslationException("Failed to connect to translation service: " + e.getMessage());
        }
    }

    private String buildPrompt(String text, String sourceLanguage) {
        return String.format(
                "You are an expert translator specializing in Moroccan Arabic Dialect (Darija). " +
                "Translate the following %s text to Moroccan Arabic Dialect (Darija). " +
                "Use authentic Moroccan Darija vocabulary and expressions. " +
                "Return ONLY the translation without any explanation or additional text.\n\n" +
                "Text to translate: %s",
                sourceLanguage, text
        );
    }

    private String buildRequestBody(String prompt) throws Exception {
        ObjectNode root = objectMapper.createObjectNode();
        ArrayNode contents = root.putArray("contents");
        ObjectNode content = contents.addObject();
        ArrayNode parts = content.putArray("parts");
        parts.addObject().put("text", prompt);

        // Safety / generation config
        ObjectNode genConfig = root.putObject("generationConfig");
        genConfig.put("temperature", 0.3);
        genConfig.put("maxOutputTokens", 1024);

        return objectMapper.writeValueAsString(root);
    }

    private String parseGeminiResponse(String responseBody) throws TranslationException {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode candidates = root.path("candidates");
            if (candidates.isArray() && candidates.size() > 0) {
                JsonNode text = candidates.get(0)
                        .path("content")
                        .path("parts")
                        .get(0)
                        .path("text");
                if (!text.isMissingNode()) {
                    return text.asText().trim();
                }
            }
            throw new TranslationException("Unexpected response structure from Gemini API.");
        } catch (TranslationException e) {
            throw e;
        } catch (Exception e) {
            throw new TranslationException("Failed to parse Gemini response: " + e.getMessage());
        }
    }
}
